package com.mindtree.Exception;

public class SubmitException extends Exception {

	private static final long serialVersionUID = 1L;

	public SubmitException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

	public SubmitException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public SubmitException(Throwable arg0) {
		super(arg0);
	}

	private String exceptionMsg;

	public String getExceptionMsg() {
		return exceptionMsg;
	}

	public void setExceptionMsg(String exceptionMsg) {
		this.exceptionMsg = exceptionMsg;
	}

	public SubmitException() {

	}

	public SubmitException(String exceptionMsg) {
		super(exceptionMsg);
		this.exceptionMsg = exceptionMsg;
	}
}
