package com.mindtree.controller;

import java.sql.Date;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.mindtree.Exception.SubmitException;
import com.mindtree.pojo.Booking_Pojo;
import com.mindtree.service.Service;

@Controller
public class WebController {
	private static final Logger logg = Logger.getLogger(WebController.class);
	@Autowired
	private Service serviceobj;

	public Service getServiceobj() {
		return serviceobj;
	}

	public static Logger getLogg() {
		return logg;
	}

	public void setServiceobj(Service serviceobj) {
		this.serviceobj = serviceobj;
	}

	@RequestMapping("/booking")
	public ModelAndView book_Hotel(Model model) {
		logg.info("Welcome to the Booking Portal");
		logg.info("List of Cities are Populated");
		model.addAttribute("cities", serviceobj.citiesList());
		logg.info("List of Cities are Stored in the cities PlaceHolders of the Booking.jsp File");
		logg.info("An instance is created with the help of Booking_Pojo and it is Appeneded to the Booking.jsp File");
		return new ModelAndView("Booking", "bookpojo", new Booking_Pojo());
	}

	@RequestMapping(value = "/search")
	public String search_Hotel(Model model) {
		logg.info("Search Page is called and Cities are populated and It ill be stored in the cities place holders");
		model.addAttribute("cities", serviceobj.citiesList());
		logg.info("Search page will be Directed");
		return "searchpage";
	}

	@ResponseBody
	@RequestMapping("/RoomBooking")
	public String bookingHotelList(@RequestParam String city) {
		logg.info("call for a bookingHotelList in the request of collecting the hotel names");
		return serviceobj.bookingPageHotelList(city);
	}

	@ResponseBody
	@RequestMapping("/Rooms")
	public String searchPageList(@RequestParam String city) {
		logg.info("For Searching page the Hotel List for the selected City will be Searching");
		return serviceobj.lowestPriceList(city);
	}

	@RequestMapping(value = "/submit", method = RequestMethod.POST)
	public String addCategory(@Valid @ModelAttribute("bookpojo") Booking_Pojo bp, BindingResult result1, Model model,
			RedirectAttributes attr) {
		logg.info("Checks whether the Entire datas are filled");
		if (result1.hasErrors()) {
			logg.info("Datas are not filled in the Booking page");
			model.addAttribute("cities", serviceobj.citiesList());
			return "Booking";

		} else {
			logg.info("Booking pages are filled properly and redirected by changing the RequestMethod");
			attr.addFlashAttribute("bookpojo", bp);
			return "redirect:/welcome";
		}
	}

	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
	public String validation(@ModelAttribute("bookpojo") Booking_Pojo bp, Model model, BindingResult result1,
			RedirectAttributes attr) throws SubmitException {
		try {
			logg.info("while submitting form datas the values will be given to the database");
			long result = serviceobj.register(bp);
			if (result > 0) {
				java.sql.Date sqlDate1 = new java.sql.Date(bp.getCheckin().getTime());
				java.sql.Date sqlDate2 = new java.sql.Date(bp.getCheckout().getTime());
				bp.setCheckin(sqlDate1);
				bp.setCheckout(sqlDate2);
				model.addAttribute("bp", bp);
				model.addAttribute("Ref", result);
				model.addAttribute("name", bp.getBookername());
				return "thankyou";
			} else {
				attr.addFlashAttribute("sorry", "Sorry Rooms not available as per your Request");
				return "redirect:/booking";
			}
		} catch (IllegalArgumentException e) {
			throw new SubmitException("You cant Refersh the page");
			// return "redirect:/except";
		}

	}

	@ResponseBody
	@RequestMapping("/price")
	public String pricecalculator(@RequestParam String city, @RequestParam String hotelname) {
		logg.info("Call for price Calculation is Activated ");
		int price = serviceobj.roomprice(city, hotelname);
		logg.info("Price value for single days is " + price);
		String hotelprice = Integer.toString(price);
		return hotelprice;

	}

	@ResponseBody
	@RequestMapping("/grandPrice")
	public String grandPriceCalculator(@RequestParam String city, @RequestParam String hotelname,
			@RequestParam Date checkindate, @RequestParam Date checkoutdate, @RequestParam String roomsneeded) {
		logg.info("Grand Price Calculation is generated");
		long numberofdays = days(checkindate, checkoutdate);
		int days = (int) numberofdays;
		days = days + 1;
		logg.info("Number of days is generated from the given details :" + days);
		int price = serviceobj.roomprice(city, hotelname);
		int roomsprice = days * price;
		int grandprice = Integer.parseInt(roomsneeded);
		roomsprice = roomsprice * grandprice;
		String hotelprice = Integer.toString(roomsprice);
		logg.info("Grand Price is calculated with help of days required, rooms needed and per room price");
		return hotelprice;

	}

	private long days(Date checkindate, Date checkoutdate) {
		long diff = (checkindate.getTime() - checkoutdate.getTime()) / 86400000;
		return Math.abs(diff);
	}

	@ExceptionHandler(SubmitException.class)
	public String exceptionhandling(SubmitException e, Model model) {
		logg.info("Page should not be reloaded");
		model.addAttribute("exception", e.getMessage());
		return "error";

	}

}
