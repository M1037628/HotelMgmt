package com.mindtree.dao;

import java.util.List;

import com.mindtree.pojo.Booking_Pojo;
import com.mindtree.pojo.Hotel_Pojo1;

public interface Booking {
	public List<Hotel_Pojo1> bookingPageHotelList(String s);

	public List<Hotel_Pojo1> lowestPriceHotel(String s);

	public long register(Booking_Pojo b);

	public List<String> citiesList();

	public int roomprice(String city, String hotelname);
}
