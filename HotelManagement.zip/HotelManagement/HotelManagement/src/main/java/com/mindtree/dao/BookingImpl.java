package com.mindtree.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.mindtree.controller.WebController;
import com.mindtree.db.Connection_Class;
import com.mindtree.pojo.Booking_Pojo;
import com.mindtree.pojo.Hotel_Pojo1;

public class BookingImpl implements Booking {
	@Autowired
	Connection_Class con;
	Hotel_Pojo1 hp;
	List<Hotel_Pojo1> emp = null;
	List<String> emp1 = null;

	public List<String> citiesList() {
		emp1 = new ArrayList<String>();
		Connection conn = con.connect();
		Statement st = null;
		ResultSet rs = null;
		String sql = "select distinct city from listofhotels";
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				emp1.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return emp1;

	}

	public List<Hotel_Pojo1> bookingPageHotelList(String name2) {
		WebController.getLogg()
				.info("City name will be given for finding the list of hotels for the Respective Cities :" + name2);
		emp = new ArrayList<Hotel_Pojo1>();
		Connection conn = con.connect();
		PreparedStatement st = null;
		ResultSet rs = null;
		String sql = "select name from listofhotels where city=?";
		WebController.getLogg().info("Query for reterving the List of hotels is generated and It is executed");
		try {
			st = conn.prepareStatement(sql);
			st.setString(1, name2);
			rs = st.executeQuery();
			while (rs.next()) {
				hp = new Hotel_Pojo1();
				hp.setName(rs.getString(1));
				emp.add(hp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		WebController.getLogg().info("Generated List will be send to the Service Class");
		return emp;
	}

	public List<Hotel_Pojo1> lowestPriceHotel(String name2) {
		emp = new ArrayList<Hotel_Pojo1>();
		Connection conn = con.connect();
		PreparedStatement st = null;
		ResultSet rs = null;
		String sql = "select name from listofhotels where city=? ORDER BY Traiff ASC";
		try {
			st = conn.prepareStatement(sql);
			st.setString(1, name2);
			rs = st.executeQuery();
			while (rs.next()) {
				hp = new Hotel_Pojo1();
				hp.setName(rs.getString(1));
				emp.add(hp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return emp;
	}

	public long register(Booking_Pojo b) {
		Date truncatedDate = DateUtils.truncate(b.getCheckin(), Calendar.DATE);
		Date truncatedDate1 = DateUtils.truncate(b.getCheckout(), Calendar.DATE);
		java.sql.Date sqlDate1 = new java.sql.Date(truncatedDate.getTime());
		java.sql.Date sqlDate2 = new java.sql.Date(truncatedDate1.getTime());

		Connection conn = con.connect();
		PreparedStatement st = null;
		PreparedStatement st1 = null;
		ResultSet rs = null;
		CallableStatement stmt = null;
		int flag = 0, say = 0;
		try {
			stmt = conn.prepareCall("call Room_Calculation(?,?,?,?,?)");
			stmt.setDate(1, sqlDate1);
			stmt.setDate(2, sqlDate2);
			stmt.setInt(3, b.getId());
			stmt.setInt(4, b.getNoofrooms());
			stmt.registerOutParameter(5, flag);
			stmt.executeUpdate();
			say = stmt.getInt(5);
		} catch (SQLException e2) {
			e2.printStackTrace();
		}
		if (say == 1) {

			long id = 0;
			int hotelid = 0;
			String sql1 = "select id from listofhotels where city=? and Name=?";
			try {
				st1 = conn.prepareStatement(sql1);
				st1.setString(1, b.getCity());
				st1.setString(2, b.getHotelname());
				rs = st1.executeQuery();
				while (rs.next()) {
					hotelid = rs.getInt(1);
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			String sql = "INSERT INTO bookingdetails(Ref_Id, city, hotelName, checkIn, checkOut, noOfRooms, hotelId, BookerName, Grandprice) VALUES (null,?,?,?,?,?,?,?,?)";

			try {
				st = conn.prepareStatement(sql);
				st.setString(1, b.getCity());
				st.setString(2, b.getHotelname());
				st.setDate(3, sqlDate1);
				st.setDate(4, sqlDate2);
				st.setInt(5, b.getNoofrooms());
				st.setInt(6, hotelid);
				st.setString(7, b.getBookername());
				st.setInt(8, b.getGrandprice());
				st.executeUpdate();
				rs = st.getGeneratedKeys();
				if (rs.next()) {
					id = rs.getLong(1);
				} else {

				}
				return id;

			} catch (

			SQLException e) {
				e.printStackTrace();
			}
		} else {
			return 0;
		}
		return say;
	}

	public int roomprice(String city, String hotelname) {
		Connection conn = con.connect();
		PreparedStatement st = null;
		ResultSet rs = null;
		int price = 0;
		String sql = "select Traiff from listofhotels where city=? and name=?";
		try {
			st = conn.prepareStatement(sql);
			st.setString(1, city);
			st.setString(2, hotelname);
			rs = st.executeQuery();
			while (rs.next()) {
				price = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return price;

	}
}
