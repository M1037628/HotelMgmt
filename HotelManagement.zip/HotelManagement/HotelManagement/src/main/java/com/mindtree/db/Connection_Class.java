package com.mindtree.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connection_Class {
	Connection conn = null;

	public Connection connect() {
		String URL = "jdbc:mysql://localhost:3306/hotelmanagement";
		String classpath = "com.mysql.jdbc.Driver";
		String USER = "root";
		String PASSWORD = "root";
		try {
			Class.forName(classpath);
			conn = DriverManager.getConnection(URL, USER, PASSWORD);

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return conn;
	}
}
