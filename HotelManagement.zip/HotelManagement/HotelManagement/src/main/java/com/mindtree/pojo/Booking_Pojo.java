package com.mindtree.pojo;

import java.util.Date;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

public class Booking_Pojo {
	@NotEmpty
	@Pattern(regexp = "[A-Za-z]*$")
	private String Bookername;
	@NotEmpty
	private String city;
	@NotEmpty
	private String hotelname;
	@NotNull
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date checkin;
	@NotNull
	@DateTimeFormat(iso = ISO.DATE)
	private Date checkout;
	@Min(1)
	private int noofrooms;
	private int id = 0;
	private int grandprice;

	public int getGrandprice() {
		return grandprice;
	}

	public void setGrandprice(int grandprice) {
		this.grandprice = grandprice;
	}

	public String getBookername() {
		return Bookername;
	}

	public void setBookername(String bookername) {
		Bookername = bookername;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getHotelname() {
		return hotelname;
	}

	public void setHotelname(String hotelname) {
		this.hotelname = hotelname;
	}

	public Date getCheckin() {
		return checkin;
	}

	public void setCheckin(Date checkin) {
		this.checkin = checkin;
	}

	public Date getCheckout() {
		return checkout;
	}

	public void setCheckout(Date checkout) {
		this.checkout = checkout;
	}

	public int getNoofrooms() {
		return noofrooms;
	}

	public void setNoofrooms(int noofrooms) {
		this.noofrooms = noofrooms;
	}

}
