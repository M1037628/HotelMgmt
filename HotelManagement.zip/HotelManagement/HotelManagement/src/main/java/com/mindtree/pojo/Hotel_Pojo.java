package com.mindtree.pojo;

public class Hotel_Pojo {
	private String name;
	private String city;
	private int noofrooms;
	private int starratting;
	private int traiffperday;
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getNoofrooms() {
		return noofrooms;
	}

	public void setNoofrooms(int noofrooms) {
		this.noofrooms = noofrooms;
	}

	public int getStarratting() {
		return starratting;
	}

	public void setStarratting(int starratting) {
		this.starratting = starratting;
	}

	public int getTraiffperday() {
		return traiffperday;
	}

	public void setTraiffperday(int traiffperday) {
		this.traiffperday = traiffperday;
	}

}
