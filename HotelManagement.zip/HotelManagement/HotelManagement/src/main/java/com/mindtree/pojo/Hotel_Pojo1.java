package com.mindtree.pojo;

public class Hotel_Pojo1 {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
