package com.mindtree.service;

import java.util.List;

import com.mindtree.pojo.Booking_Pojo;

public interface Service {
	public String bookingPageHotelList(String s);

	public String lowestPriceList(String s);

	public long register(Booking_Pojo b);

	public List<String> citiesList();

	public int roomprice(String city, String hotelname);

}
