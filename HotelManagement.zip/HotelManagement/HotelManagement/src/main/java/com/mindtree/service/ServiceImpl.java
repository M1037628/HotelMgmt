package com.mindtree.service;

import java.io.IOException;
import java.util.List;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;

import com.mindtree.controller.WebController;
import com.mindtree.dao.Booking;
import com.mindtree.pojo.Booking_Pojo;
import com.mindtree.pojo.Hotel_Pojo1;

public class ServiceImpl implements Service {
	@Autowired
	ObjectMapper om;
	private Booking bookdao;

	public Booking getBookdao() {
		return bookdao;
	}

	public void setBookdao(Booking bookdao) {
		this.bookdao = bookdao;
	}

	public String bookingPageHotelList(String s) {
		List<Hotel_Pojo1> a = bookdao.bookingPageHotelList(s);
		WebController.getLogg().info("List of JSON datas are Generated");
		String name1 = null;
		try {
			WebController.getLogg().info("Json Datas are converted to string using objectmapper");
			name1 = om.writeValueAsString(a);
		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		WebController.getLogg().info("Hotels name will be return to the main controller ");
		return name1;

	}

	public String lowestPriceList(String s) {

		List<Hotel_Pojo1> a = bookdao.lowestPriceHotel(s);
		String name1 = null;
		try {
			name1 = om.writeValueAsString(a);
		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return name1;

	}

	public long register(Booking_Pojo b) {
		return bookdao.register(b);
	}

	public List<String> citiesList() {
		return bookdao.citiesList();
	}

	public int roomprice(String city, String hotelname) {
		return bookdao.roomprice(city, hotelname);
	}

}
