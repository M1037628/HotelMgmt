$(document).ready(function() {

	$('#dt2').datepicker({
		dateFormat : "yy-mm-dd"
	});

	$("#dt1").datepicker({
		dateFormat : "yy-mm-dd",
		minDate : 0,
		onSelect : function(date) {
			var date1 = $('#dt1').datepicker('getDate');
			var date = new Date(Date.parse(date1));
			date.setDate(date.getDate());
			var newDate = date.toDateString();
			newDate = new Date(Date.parse(newDate));
			$('#dt2').datepicker("option", "minDate", newDate);
		}
	});

});
