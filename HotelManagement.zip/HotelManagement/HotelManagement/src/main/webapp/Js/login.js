function sample() {
	var value = document.getElementById("category").value;
	var citys = document.getElementById("name").value;
	$.ajax({
		contentType : "application/json; charset=utf-8",
		data : {
			'hotelname' : value,
			'city' : citys
		},
		url : "price", // the file to call
		success : function(response) {
			if (document.getElementById("dt1").value != "Choose ur date") {
				document.getElementById("gran").value = "";
			} else {

			}
			document.getElementById("pricevalue").value = response;
		},
		error : function() {
			alert("error");
		}
	})
}
function grand(total) {
	var value = document.getElementById("category").value;
	var citys = document.getElementById("name").value;
	var checkin = new Date();
	var checkout = new Date();
	checkin = document.getElementById("dt1").value;
	checkout = document.getElementById("dt2").value;
	$.ajax({
		contentType : "application/json; charset=utf-8",
		data : {
			'hotelname' : value,
			'city' : citys,
			'checkindate' : checkin,
			'checkoutdate' : checkout,
			'roomsneeded' : total
		},
		url : "grandPrice", // the file to call
		success : function(response) {
			document.getElementById("grandvalue").value = response;
		},
		error : function() {
			alert("error");
		}
	})
}
function hotelList(value) {
	$.ajax({ // create an AJAX call...
		contentType : "application/json; charset=utf-8",
		data : {
			'city' : value
		},

		url : "RoomBooking", // the file to call
		success : function(response) {
			var jsonData = JSON.parse(response);
			var hotellist = [];
			for (var i = 0; i < jsonData.length; i++) {
				hotellist[i] = jsonData[i].name;
			}

			var text = "<option disabled selected>--Select--</option>";

			for (var i = 0; i < hotellist.length; i++) {
				text += "<option>" + hotellist[i] + "</option>";
			}

			document.getElementById("category").innerHTML = text;
		},
		error : function() {
			alert("error");
		}
	})

}
