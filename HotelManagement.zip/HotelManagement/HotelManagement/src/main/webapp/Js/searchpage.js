function tryy(value) {
}

function lists(value) {
	$.ajax({ // create an AJAX call...
		contentType : "application/json; charset=utf-8",
		data : {
			'city' : value
		},

		url : "RoomBooking", // the file to call
		success : function(response) {
			var jsonData = JSON.parse(response);
			var hotellist = [];
			for (var i = 0; i < jsonData.length; i++) {
				hotellist[i] = jsonData[i].name;
			}
			var text = "<option disabled selected>Select</option>";
			for (var i = 0; i < hotellist.length; i++) {

				text += "<option>" + hotellist[i] + "</option>";
			}
			document.getElementById("category").innerHTML = text;
		},
		error : function() {
			alert("error");
		}
	})

}

