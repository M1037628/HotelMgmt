package com.mindtree.TestClass;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mindtree.controller.WebController;
import com.mindtree.service.Service;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
public class WebControllerTest {

	@Configuration
	static class WebControllerTestConfiguration {
		@Bean
		public Service service() {
			return Mockito.mock(Service.class);
		}

		@Bean
		public WebController webController() {
			return new WebController();
		}
	}

	@Autowired
	private Service serviceobj;

	@Autowired
	private WebController webController;
	private MockMvc mockMvc;

	@Before
	public void MockMvcObject() {
		mockMvc = MockMvcBuilders.standaloneSetup(this.webController).build();
	}

	@Test
	public void Book_HotelTest() throws Exception {

		mockMvc.perform(get("/booking"))
		.andExpect(status().isOk())
		.andExpect(view().name("Booking"))
		.andExpect(model().attributeExists("cities"));
	}

	@Test
	public void Search_HotelTest() throws Exception {

		mockMvc.perform(get("/search"))
		.andExpect(status().isOk())
		.andExpect(view().name("searchpage"))
		.andExpect(model().attributeExists("cities"));
	}

}
