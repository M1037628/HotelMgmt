
Table-1: List Of Hotels
-------------------------------------------------------------------------------------
| listofhotels | CREATE TABLE `listofhotels` (
  `Name` varchar(45) NOT NULL DEFAULT '',
  `City` varchar(45) NOT NULL DEFAULT '',
  `No_of_rooms` int(10) unsigned NOT NULL DEFAULT '0',
  `Star_rating` varchar(45) NOT NULL DEFAULT '',
  `Traiff` int(10) unsigned NOT NULL DEFAULT '0',
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) 




Table-2: Booking Details
-------------------------------------------------------------------------------------
| bookingdetails | CREATE TABLE `bookingdetails` (
  `Ref_Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `city` varchar(45) NOT NULL DEFAULT '',
  `hotelName` varchar(45) NOT NULL DEFAULT '',
  `checkIn` date NOT NULL DEFAULT '0000-00-00',
  `checkOut` date NOT NULL DEFAULT '0000-00-00',
  `noOfRooms` int(10) unsigned NOT NULL DEFAULT '0',
  `hotelId` int(10) unsigned NOT NULL DEFAULT '0',
  `BookerName` varchar(45) DEFAULT NULL,
  `Grandprice` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`Ref_Id`),
  KEY `FK_bookingdetails_1` (`hotelId`),
  CONSTRAINT `FK_bookingdetails_1` FOREIGN KEY (`hotelId`) REFERENCES `listofhot
els` (`id`)
) 





Stored Procedure :
-------------------------------------------------------------------------------------

DELIMITER $$

DROP PROCEDURE IF EXISTS `hotelmanagement`.`Room_Calculation` $$
CREATE  PROCEDURE `Room_Calculation`(in check_in_date date,in check_out_date date,in hotel_id int,in roomsNeeded int,inout flag int)
BEGIN
   declare P_Date_RB int;
   declare hotelRooms int;
   declare available int;
   declare newDate date;
   declare ifcond int;

     SET max_sp_recursion_depth=255;

   SET flag=0;
   set P_Date_RB=(SELECT sum(noofrooms) FROM bookingdetails b where check_in_date between b.checkin and b.checkout);
   set hotelRooms=(select No_of_rooms from listofhotels h where h.id=hotel_id);
   set ifcond=(select DATEDIFF(check_out_date,check_in_date));

   if (P_Date_RB is NULL) then

     set P_Date_RB=0;

   end if;

   set available=hotelRooms-P_Date_RB;

   if (roomsNeeded<=available) then

      set flag=1;


               if (ifcond!=0) then


                  set newDate=(select date_add(check_in_date,interval 1 day));
                  call hotelmanagement.Room_Calculation(newDate,check_out_date,hotel_id,roomsNeeded,flag);


               end if;
     end if;

END $$

DELIMITER ;